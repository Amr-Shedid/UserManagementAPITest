using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IO;
using System.Linq;

var builder = WebApplication.CreateBuilder(args);

// configure simple JWT authentication for demonstration
var jwtSecret = "SuperSecretKeyForDevDontUseInProd";
// expose to configuration so middleware can read it
builder.Configuration["JwtSecret"] = jwtSecret;

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = false,
        ValidateAudience = false,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret))
    };
});

builder.Services.AddAuthorization();

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// add custom middleware components
// 1. exception handler at the very beginning
app.UseMiddleware<MyApi.Middleware.ExceptionHandlingMiddleware>();

// 2. built-in authentication/authorization and token validation
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<MyApi.Middleware.TokenValidationMiddleware>();

// 3. logging/auditing last so it sees the final status code
app.UseMiddleware<MyApi.Middleware.RequestResponseLoggingMiddleware>();


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// user management backing store 
var users = new List<User>();
var nextUserId = 1;

// CRUD endpoints for internal user management
app.MapGet("/users", (int? page, int? pageSize, ILogger<Program> log) =>
{
    try
    {
        log.LogInformation("Fetching users; page={Page}, size={Size}, total={Total}", page, pageSize, users.Count);
        var query = users.AsEnumerable();
        if (page.HasValue && pageSize.HasValue && page > 0 && pageSize > 0)
        {
            query = query.Skip((page.Value - 1) * pageSize.Value).Take(pageSize.Value);
        }
        var result = query.ToArray();
        return Results.Ok(result);
    }
    catch (Exception ex)
    {
        log.LogError(ex, "Error fetching users");
        return Results.Problem(detail: ex.Message, statusCode: 500);
    }
})
   .WithName("GetUsers")
   .WithOpenApi()
   .RequireAuthorization();

app.MapGet("/users/{id}", (int id, ILogger<Program> log) =>
{
    try
    {
        var user = users.FirstOrDefault(u => u.Id == id);
        if (user is null)
        {
            log.LogWarning("User with id {Id} not found", id);
            return Results.NotFound();
        }
        return Results.Ok(user);
    }
    catch (Exception ex)
    {
        log.LogError(ex, "Error retrieving user {Id}", id);
        return Results.Problem(detail: ex.Message, statusCode: 500);
    }
})
   .WithName("GetUserById")
   .WithOpenApi()
   .RequireAuthorization();

app.MapPost("/users", (UserCreationDto newUser, ILogger<Program> log) =>
{
    try
    {
        // simple validation
        if (string.IsNullOrWhiteSpace(newUser.Name) || string.IsNullOrWhiteSpace(newUser.Email))
        {
            log.LogWarning("Invalid user creation request: {@User}", newUser);
            return Results.BadRequest(new { error = "Name and Email are required." });
        }
        try
        {
            _ = new System.Net.Mail.MailAddress(newUser.Email);
        }
        catch
        {
            log.LogWarning("Invalid email format: {Email}", newUser.Email);
            return Results.BadRequest(new { error = "Email format is invalid." });
        }

        var user = new User { Id = nextUserId++, Name = newUser.Name, Email = newUser.Email };
        users.Add(user);
        log.LogInformation("Created user {Id}", user.Id);
        return Results.Created($"/users/{user.Id}", user);
    }
    catch (Exception ex)
    {
        log.LogError(ex, "Error creating user");
        return Results.Problem(detail: ex.Message, statusCode: 500);
    }
})
   .WithName("CreateUser")
   .WithOpenApi()
   .RequireAuthorization();

app.MapPut("/users/{id}", (int id, UserUpdateDto updated, ILogger<Program> log) =>
{
    try
    {
        var existing = users.FirstOrDefault(u => u.Id == id);
        if (existing is null)
        {
            log.LogWarning("Attempt to update non-existent user {Id}", id);
            return Results.NotFound();
        }

        if (string.IsNullOrWhiteSpace(updated.Name) || string.IsNullOrWhiteSpace(updated.Email))
        {
            log.LogWarning("Invalid update for user {Id}: {@Update}", id, updated);
            return Results.BadRequest(new { error = "Name and Email are required." });
        }
        try
        {
            _ = new System.Net.Mail.MailAddress(updated.Email);
        }
        catch
        {
            log.LogWarning("Invalid email format on update for user {Id}: {Email}", id, updated.Email);
            return Results.BadRequest(new { error = "Email format is invalid." });
        }

        existing.Name = updated.Name;
        existing.Email = updated.Email;
        log.LogInformation("Updated user {Id}", id);
        return Results.NoContent();
    }
    catch (Exception ex)
    {
        log.LogError(ex, "Error updating user {Id}", id);
        return Results.Problem(detail: ex.Message, statusCode: 500);
    }
})
   .WithName("UpdateUser")
   .WithOpenApi()
   .RequireAuthorization();

app.MapDelete("/users/{id}", (int id, ILogger<Program> log) =>
{
    try
    {
        var removed = users.RemoveAll(u => u.Id == id);
        if (removed > 0)
        {
            log.LogInformation("Deleted user {Id}", id);
            return Results.NoContent();
        }
        log.LogWarning("Delete called for non-existent user {Id}", id);
        return Results.NotFound();
    }
    catch (Exception ex)
    {
        log.LogError(ex, "Error deleting user {Id}", id);
        return Results.Problem(detail: ex.Message, statusCode: 500);
    }
})
   .WithName("DeleteUser")
   .WithOpenApi()
   .RequireAuthorization();


app.Run();

// User management models
class User
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}

record UserCreationDto(string Name, string Email);
record UserUpdateDto(string Name, string Email);
