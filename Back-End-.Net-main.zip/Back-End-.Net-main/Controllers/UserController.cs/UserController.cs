using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

public class User
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Name is required")] 
    public string Name { get; set; } = string.Empty;
    [Required(ErrorMessage = "Email is required")] 
    public string Email { get; set; } = string.Empty;
}

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private static List<User> users = new List<User>();
    private static int nextId = 1;

    [HttpGet]
    public ActionResult<IEnumerable<User>> GetUsers()
    {
        try
        {
            return Ok(users);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpGet("{id}")]
    public ActionResult<User> GetUser(int id)
    {
        try
        {
            var user = users.FirstOrDefault(u => u.Id == id);
            if (user == null) return NotFound("User not found");
            return Ok(user);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpPost]
    public ActionResult<User> CreateUser([FromBody] User newUser)
    {
        try
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            newUser.Id = nextId++;
            users.Add(newUser);

            return CreatedAtAction(nameof(GetUser), new { id = newUser.Id }, newUser);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpPut("{id}")]
    public ActionResult<User> UpdateUser(int id, [FromBody] User updatedUser)
    {
        try
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = users.FirstOrDefault(u => u.Id == id);
            if (user == null) return NotFound("User not found");

            // Update only changed fields
            user.Name = updatedUser.Name ?? user.Name;
            user.Email = updatedUser.Email ?? user.Email;

            return Ok(user);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpDelete("{id}")]
    public ActionResult<User> DeleteUser(int id)
    {
        try
        {
            var index = users.FindIndex(u => u.Id == id);
            if (index == -1) return NotFound("User not found");

            var deletedUser = users[index];
            users.RemoveAt(index);

            return Ok(deletedUser);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }
}